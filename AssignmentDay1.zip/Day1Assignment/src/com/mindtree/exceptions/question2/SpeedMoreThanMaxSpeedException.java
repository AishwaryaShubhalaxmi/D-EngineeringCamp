package com.mindtree.exceptions.question2;

public class SpeedMoreThanMaxSpeedException extends Exception {

}
