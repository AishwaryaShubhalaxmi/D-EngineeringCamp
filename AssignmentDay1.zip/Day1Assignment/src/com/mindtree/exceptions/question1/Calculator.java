package com.mindtree.exceptions.question1;

public class Calculator {
	
	
	public static int add(int number1, int number2){
		
		return 0;
	}
	
	public static int subtract(int number1, int number2){
		
		
		return 0;
	}
	
	public static int multiply(int number1, int number2){
		
		
		return 0;
	}
	
	public static double divide(int number1, int number2){
		
		
		return 0;
	}

}
