package com.mindtree.collections.question3;

import java.util.ArrayList;

/**
 * Word Count
 * 
 * 
 * 
 */
public class WordCount{

	/**
	 * @return HashMap a map containing the Character count, Word count and Sentence count
     *
	 */
	public ArrayList<Integer> countWord(int lineNumber){
	
		return null;
	}
}

